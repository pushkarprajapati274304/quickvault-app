import React from 'react';
import { X, Download, Bookmark, Trash2, FileText, Share2 } from 'lucide-react';
import { VaultItem, formatBytes } from '../lib/db';

interface PreviewModalProps {
  item: VaultItem;
  onClose: () => void;
  onToggleFavorite: (id: string) => void;
  onDelete: (id: string) => void;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({
  item,
  onClose,
  onToggleFavorite,
  onDelete,
}) => {
  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = item.dataUrl;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.name,
          text: `Sharing file from QuickVault: ${item.name}`,
        });
      } catch (err) {
        console.warn('Share cancelled or not supported', err);
      }
    } else {
      handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0a0f0d] pt-safe pb-safe select-none">
      {/* Top App Bar */}
      <header className="flex items-center justify-between px-4 py-3 bg-[#0d1411]/90 backdrop-blur-md border-b border-[#1b2822]">
        <button
          onClick={onClose}
          className="p-2 rounded-full hover:bg-white/10 active:scale-95 text-slate-300"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0 mx-3 text-center">
          <p className="text-sm font-semibold text-slate-100 truncate">{item.name}</p>
          <p className="text-[11px] text-slate-400">
            {item.type.toUpperCase()} · {formatBytes(item.size)}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onToggleFavorite(item.id)}
            className={`p-2 rounded-full hover:bg-white/10 active:scale-95 ${
              item.isFavorite ? 'text-amber-400' : 'text-slate-400'
            }`}
          >
            <Bookmark className="w-5 h-5" fill={item.isFavorite ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={() => onDelete(item.id)}
            className="p-2 rounded-full hover:bg-rose-500/20 active:scale-95 text-rose-400"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Preview Area */}
      <div className="flex-1 flex items-center justify-center p-2 overflow-hidden bg-black/40">
        {item.type === 'photo' ? (
          <img
            src={item.dataUrl}
            alt={item.name}
            className="max-h-full max-w-full rounded-xl object-contain shadow-2xl"
          />
        ) : item.type === 'video' ? (
          <video
            src={item.dataUrl}
            controls
            autoPlay
            playsInline
            className="max-h-full max-w-full rounded-xl shadow-2xl"
          />
        ) : (
          <div className="flex flex-col items-center justify-center p-8 bg-[#121c17] rounded-3xl border border-[#1e2f26] max-w-xs text-center shadow-xl">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/15 flex items-center justify-center text-emerald-400 mb-4">
              <FileText className="w-8 h-8" />
            </div>
            <p className="font-semibold text-sm text-slate-200 break-all">{item.name}</p>
            <p className="text-xs text-slate-400 mt-1">{formatBytes(item.size)}</p>
            <button
              onClick={handleDownload}
              className="mt-6 px-5 py-2.5 rounded-full gradient-accent text-xs font-bold text-black"
            >
              Open File
            </button>
          </div>
        )}
      </div>

      {/* Bottom Actions Bar */}
      <footer className="flex items-center gap-3 px-4 py-3 bg-[#0d1411]/90 backdrop-blur-md border-t border-[#1b2822]">
        <button
          onClick={handleShare}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#15201b] hover:bg-[#1a2922] text-xs font-semibold text-slate-200 border border-[#203328] active:scale-98 transition"
        >
          <Share2 className="w-4 h-4 text-emerald-400" />
          Share
        </button>
        <button
          onClick={handleDownload}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl gradient-accent text-xs font-bold text-black active:scale-98 transition shadow-lg shadow-emerald-500/20"
        >
          <Download className="w-4 h-4" />
          Save to Phone
        </button>
      </footer>
    </div>
  );
};
