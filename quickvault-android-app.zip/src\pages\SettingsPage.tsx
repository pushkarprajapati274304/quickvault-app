import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  KeyRound,
  Fingerprint,
  Trash2,
  HardDrive,
  ShieldCheck,
  FileText,
  ExternalLink,
  Check,
} from 'lucide-react';
import {
  isPinSet,
  setAppPin,
  removeAppPin,
  isBiometricEnabled,
  setBiometricEnabled,
  canUseBiometrics,
} from '../lib/applock';
import { getAllVaultItems, formatBytes } from '../lib/db';

interface SettingsPageProps {
  onBack: () => void;
  onOpenAbout: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onBack, onOpenAbout }) => {
  const [hasPin, setHasPin] = useState<boolean>(isPinSet());
  const [newPin, setNewPin] = useState<string>('');
  const [pinPromptOpen, setPinPromptOpen] = useState<boolean>(false);
  const [pinSuccess, setPinSuccess] = useState<boolean>(false);
  const [biometricsOn, setBiometricsOn] = useState<boolean>(isBiometricEnabled());
  const [stats, setStats] = useState<{ count: number; totalBytes: number }>({ count: 0, totalBytes: 0 });

  useEffect(() => {
    getAllVaultItems().then((items) => {
      const bytes = items.reduce((acc, curr) => acc + curr.size, 0);
      setStats({ count: items.length, totalBytes: bytes });
    });
  }, []);

  const handleSavePin = async () => {
    if (newPin.length < 4) return;
    await setAppPin(newPin);
    setHasPin(true);
    setPinPromptOpen(false);
    setNewPin('');
    setPinSuccess(true);
    setTimeout(() => setPinSuccess(false), 2000);
  };

  const handleRemovePin = () => {
    if (confirm('Are you sure you want to disable PIN lock? Anyone can view your vault.')) {
      removeAppPin();
      setHasPin(false);
      setBiometricsOn(false);
    }
  };

  const handleBiometricToggle = () => {
    const next = !biometricsOn;
    setBiometricEnabled(next);
    setBiometricsOn(next);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0f0d] text-slate-100 select-none pt-safe pb-safe">
      {/* Header */}
      <header className="px-4 py-3.5 flex items-center gap-3 border-b border-[#18241e] bg-[#0c1410]">
        <button
          onClick={onBack}
          className="p-2 rounded-full hover:bg-white/10 active:scale-95 text-slate-300"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-base font-bold text-white">Vault Settings</h1>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto px-4 py-5 space-y-6">
        {/* Storage Stats */}
        <section className="bg-[#121c17] border border-[#1e2f26] rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Vault Storage Used</p>
              <p className="text-lg font-bold text-white leading-snug">
                {formatBytes(stats.totalBytes)}{' '}
                <span className="text-xs font-normal text-slate-400">({stats.count} files)</span>
              </p>
            </div>
          </div>
        </section>

        {/* Security Section */}
        <section className="space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
            Security & Privacy
          </h2>

          <div className="bg-[#121c17] border border-[#1e2f26] rounded-2xl overflow-hidden divide-y divide-[#1e2f26]">
            {/* PIN Row */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <KeyRound className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-sm font-semibold text-slate-200">PIN Code Lock</p>
                  <p className="text-xs text-slate-400">
                    {hasPin ? 'PIN is currently active' : 'No PIN configured'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {hasPin && (
                  <button
                    onClick={handleRemovePin}
                    className="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-300"
                  >
                    Remove
                  </button>
                )}
                <button
                  onClick={() => setPinPromptOpen(true)}
                  className="px-3.5 py-1.5 rounded-full gradient-accent text-xs font-bold text-black shadow active:scale-95 transition"
                >
                  {hasPin ? 'Change PIN' : 'Set PIN'}
                </button>
              </div>
            </div>

            {/* Biometrics Row */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Fingerprint className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-sm font-semibold text-slate-200">Biometric Unlock</p>
                  <p className="text-xs text-slate-400">Fingerprint / Face ID</p>
                </div>
              </div>
              <button
                onClick={handleBiometricToggle}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  biometricsOn ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    biometricsOn ? 'translate-x-6' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
          </div>

          {pinSuccess && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-300 font-medium">
              <Check className="w-4 h-4" /> PIN updated successfully!
            </div>
          )}
        </section>

        {/* Set PIN Modal Sheet */}
        {pinPromptOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
            <div className="bg-[#121c17] border border-[#1f3127] rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
              <h3 className="font-bold text-base text-white">Create 4–6 Digit PIN</h3>
              <p className="text-xs text-slate-400">
                Choose a passcode that will protect your hidden vault.
              </p>
              <input
                type="password"
                maxLength={6}
                inputMode="numeric"
                autoFocus
                placeholder="Enter numbers..."
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                className="w-full text-center text-2xl tracking-widest py-3 bg-[#0a0f0d] border border-[#1f3127] rounded-2xl text-emerald-400 font-mono focus:outline-none focus:border-emerald-500"
              />
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => {
                    setPinPromptOpen(false);
                    setNewPin('');
                  }}
                  className="flex-1 py-3 rounded-2xl bg-[#1a2922] text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSavePin}
                  disabled={newPin.length < 4}
                  className="flex-1 py-3 rounded-2xl gradient-accent text-xs font-bold text-black disabled:opacity-50"
                >
                  Save PIN
                </button>
              </div>
            </div>
          </div>
        )}

        {/* App Info & Play Store Compliance Links */}
        <section className="space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">About</h2>
          <div className="bg-[#121c17] border border-[#1e2f26] rounded-2xl divide-y divide-[#1e2f26] overflow-hidden">
            <button
              onClick={onOpenAbout}
              className="w-full p-4 flex items-center justify-between text-left hover:bg-white/5 active:scale-98 transition"
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-semibold text-slate-200">How QuickVault Works</span>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-500" />
            </button>

            <a
              href="/privacy-policy.html"
              target="_blank"
              rel="noreferrer"
              className="w-full p-4 flex items-center justify-between text-left hover:bg-white/5 active:scale-98 transition"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-semibold text-slate-200">Privacy Policy</span>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-500" />
            </a>
          </div>
        </section>

        <p className="text-center text-[11px] text-slate-600 pt-4">
          QuickVault v1.0.0 · 100% Private On-Device Vault
        </p>
      </main>
    </div>
  );
};
