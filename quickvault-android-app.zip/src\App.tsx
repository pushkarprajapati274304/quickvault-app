import React, { useState, useEffect } from 'react';
import { VaultPage } from './pages/VaultPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';
import { AppLockModal } from './components/AppLockModal';
import { isPinSet } from './lib/applock';

type Screen = 'vault' | 'settings' | 'about';

export const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('vault');
  const [isLocked, setIsLocked] = useState<boolean>(isPinSet());

  useEffect(() => {
    // Lock automatically when app is minimized or sent to background
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && isPinSet()) {
        setIsLocked(true);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  if (isLocked) {
    return <AppLockModal onUnlocked={() => setIsLocked(false)} />;
  }

  return (
    <div className="w-full h-full max-w-md mx-auto relative flex flex-col bg-[#0a0f0d] overflow-hidden">
      {currentScreen === 'vault' && (
        <VaultPage
          onOpenSettings={() => setCurrentScreen('settings')}
          onLockApp={() => setIsLocked(true)}
        />
      )}
      {currentScreen === 'settings' && (
        <SettingsPage
          onBack={() => setCurrentScreen('vault')}
          onOpenAbout={() => setCurrentScreen('about')}
        />
      )}
      {currentScreen === 'about' && (
        <AboutPage onBack={() => setCurrentScreen('settings')} />
      )}
    </div>
  );
};

export default App;
