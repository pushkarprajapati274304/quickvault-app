# 🚀 Google Play Store Publishing Guide (100% Free Method)

This guide shows you how to build your **.AAB (Play Store Bundle)** and **.APK (Test File)** for free using GitHub Actions and upload them to Google Play Console.

---

## Step 1: Push Code to GitHub (Free)

1. Create a **New Repository** on [github.com](https://github.com) (e.g. `quickvault-android`). Set it to **Private** or **Public**.
2. Push the files from this folder (`quickvault-app`) to your GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit for QuickVault Android"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/quickvault-android.git
   git push -u origin main
   ```

---

## Step 2: Download Your .AAB and .APK in 2 Minutes!

1. Go to your repository on GitHub.
2. Click on the **Actions** tab at the top.
3. You will see the workflow: **"Build Android APK and AAB (Play Store Bundle)"** running automatically!
4. Once it completes (takes ~2 minutes), click on the completed run.
5. At the bottom under **Artifacts**, you will see:
   - 📱 **`QuickVault-Release-APK`**: Download this `.zip`, extract the `.apk`, and install it directly on your Android phone to test!
   - 🚀 **`QuickVault-PlayStore-AAB`**: Download this `.aab` file to upload straight to Google Play Console!

---

## Step 3: Google Play Console Upload Checklist

When creating the app in [Google Play Console](https://play.google.com/console):

### 1. App Details
- **App Name**: `QuickVault – Private Media & File Vault`
- **Short Description**: `Hide photos, videos and files behind secure PIN and fingerprint lock.`
- **Full Description**:
  ```text
  QuickVault is your ultimate private media and document vault designed to keep your personal memories and sensitive files completely safe and hidden on your device.

  Key Features:
  🔒 PIN & Biometric Lock: Protect your private vault with a 4-6 digit passcode or your phone's fingerprint sensor.
  📁 Category Sorting: Automatically organize hidden items into Photos, Videos, and Documents.
  ⚡ Full-Screen Media Player: View high-resolution photos and play back hidden videos smoothly with full controls.
  📥 Easy Import & Export: Add files from your device and export them back to your gallery with one tap.
  🛡️ 100% Private: All files stay strictly on your device storage. No external servers, no tracking.
  ```

### 2. Privacy Policy URL
Host `public/privacy-policy.html` on GitHub Pages or Netlify for free:
- In GitHub repository Settings -> **Pages** -> Source: `main` branch, folder `/` or Netlify.
- Paste the live link into Google Play Console's Privacy Policy field.

### 3. App Access & Permissions
- Select: **"All functionality is available without special access"**.
- Media permissions: Selected for photo & video import/export.

---

## Step 4: Release
1. Under **Production** (or **Closed Testing**), click **Create new release**.
2. Drag and drop the downloaded **`QuickVault-PlayStore-AAB`** file.
3. Enter release notes: `Initial release of QuickVault.`
4. Click **Save** and **Review Release** -> Submit for review!
