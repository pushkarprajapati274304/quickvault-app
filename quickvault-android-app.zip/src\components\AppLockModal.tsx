import React, { useState, useEffect } from 'react';
import { Lock, Fingerprint, Delete, ShieldCheck } from 'lucide-react';
import { verifyAppPin, promptBiometricAuth, isBiometricEnabled } from '../lib/applock';

interface AppLockModalProps {
  onUnlocked: () => void;
}

export const AppLockModal: React.FC<AppLockModalProps> = ({ onUnlocked }) => {
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<boolean>(false);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  useEffect(() => {
    // Attempt biometric automatically on open if enabled
    if (isBiometricEnabled()) {
      promptBiometricAuth().then((success) => {
        if (success) onUnlocked();
      });
    }
  }, [onUnlocked]);

  const handleKeyPress = async (digit: string) => {
    if (pin.length >= 6) return;
    const newPin = pin + digit;
    setPin(newPin);
    setError(false);

    if (newPin.length >= 4) {
      setIsVerifying(true);
      const valid = await verifyAppPin(newPin);
      setIsVerifying(false);
      if (valid) {
        onUnlocked();
      } else if (newPin.length === 6) {
        // Shaking error
        setError(true);
        if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
        setTimeout(() => {
          setPin('');
          setError(false);
        }, 600);
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleBiometricClick = async () => {
    const success = await promptBiometricAuth();
    if (success) onUnlocked();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-[#0a0f0d] px-6 py-12 select-none pt-safe pb-safe">
      {/* Top Header */}
      <div className="flex flex-col items-center mt-6">
        <div className="w-16 h-16 rounded-3xl gradient-accent flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-4">
          <Lock className="w-8 h-8 text-black" strokeWidth={2.5} />
        </div>
        <h2 className="text-2xl font-bold text-white tracking-tight">QuickVault</h2>
        <p className="text-xs text-emerald-400 font-medium uppercase tracking-widest mt-1">
          Vault Locked
        </p>
        <p className="text-xs text-slate-400 mt-2">Enter PIN to access your private files</p>

        {/* PIN Dots */}
        <div className={`flex items-center gap-3 mt-8 transition-transform ${error ? 'animate-bounce' : ''}`}>
          {[0, 1, 2, 3].map((idx) => (
            <div
              key={idx}
              className={`w-3.5 h-3.5 rounded-full transition-all duration-200 ${
                pin.length > idx
                  ? error
                    ? 'bg-rose-500 scale-110 shadow-lg shadow-rose-500/50'
                    : 'bg-emerald-400 scale-110 shadow-lg shadow-emerald-400/50'
                  : 'bg-slate-700/60 border border-slate-600/40'
              }`}
            />
          ))}
        </div>
        {error && (
          <p className="text-xs text-rose-400 font-medium mt-3">Incorrect PIN. Try again.</p>
        )}
      </div>

      {/* Keypad */}
      <div className="w-full max-w-xs grid grid-cols-3 gap-4 mb-4">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
          <button
            key={digit}
            onClick={() => handleKeyPress(digit)}
            className="h-16 rounded-2xl bg-[#131d18] hover:bg-[#1a2922] active:scale-95 text-xl font-bold text-white border border-[#1f3027] transition flex items-center justify-center shadow-sm"
          >
            {digit}
          </button>
        ))}

        {/* Biometric Button */}
        <button
          onClick={handleBiometricClick}
          className="h-16 rounded-2xl bg-[#131d18] hover:bg-[#1a2922] active:scale-95 text-emerald-400 border border-[#1f3027] transition flex items-center justify-center"
          title="Fingerprint Unlock"
        >
          <Fingerprint className="w-6 h-6" />
        </button>

        {/* '0' Button */}
        <button
          onClick={() => handleKeyPress('0')}
          className="h-16 rounded-2xl bg-[#131d18] hover:bg-[#1a2922] active:scale-95 text-xl font-bold text-white border border-[#1f3027] transition flex items-center justify-center shadow-sm"
        >
          0
        </button>

        {/* Delete Button */}
        <button
          onClick={handleDelete}
          className="h-16 rounded-2xl bg-[#131d18] hover:bg-[#1a2922] active:scale-95 text-slate-400 border border-[#1f3027] transition flex items-center justify-center"
          title="Backspace"
        >
          <Delete className="w-6 h-6" />
        </button>
      </div>

      <div className="flex items-center gap-2 text-[11px] text-slate-500">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
        <span>Hardware-grade on-device encryption</span>
      </div>
    </div>
  );
};
