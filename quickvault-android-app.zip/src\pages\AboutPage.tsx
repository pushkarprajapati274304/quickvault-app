import React from 'react';
import { ArrowLeft, Shield, Lock, EyeOff, Smartphone, Database } from 'lucide-react';

interface AboutPageProps {
  onBack: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onBack }) => {
  return (
    <div className="flex flex-col h-full bg-[#0a0f0d] text-slate-100 select-none pt-safe pb-safe">
      <header className="px-4 py-3.5 flex items-center gap-3 border-b border-[#18241e] bg-[#0c1410]">
        <button
          onClick={onBack}
          className="p-2 rounded-full hover:bg-white/10 active:scale-95 text-slate-300"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-base font-bold text-white">How QuickVault Works</h1>
      </header>

      <main className="flex-1 overflow-y-auto px-5 py-6 space-y-6">
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-3xl gradient-accent flex items-center justify-center text-black mb-3 shadow-lg shadow-emerald-500/20">
            <Shield className="w-8 h-8" strokeWidth={2.5} />
          </div>
          <h2 className="text-xl font-bold text-white">Your True Private Vault</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            QuickVault was engineered with absolute zero-compromise privacy for your personal photos, videos, and documents.
          </p>
        </div>

        <div className="space-y-4">
          <div className="bg-[#121c17] border border-[#1e2f26] rounded-2xl p-4 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <EyeOff className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-200">100% On-Device Isolation</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Files stored inside QuickVault are kept inside your phone's private storage sandbox. They do not upload to any hidden third-party cloud.
              </p>
            </div>
          </div>

          <div className="bg-[#121c17] border border-[#1e2f26] rounded-2xl p-4 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-200">Hardware Biometrics & PIN</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Unlock instantly with Android's secure BiometricPrompt (fingerprint or face unlock) or custom 4-6 digit passcode.
              </p>
            </div>
          </div>

          <div className="bg-[#121c17] border border-[#1e2f26] rounded-2xl p-4 flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-200">One-Tap Export to Device</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                You can save any hidden file back to your phone's main gallery or files app anytime with a single tap.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
