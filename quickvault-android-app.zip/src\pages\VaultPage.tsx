import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Plus,
  Play,
  FileText,
  Bookmark,
  Shield,
  Settings,
  Image as ImageIcon,
  Film,
  FolderOpen,
} from 'lucide-react';
import { VaultItem, getAllVaultItems, saveVaultItem, deleteVaultItem, toggleFavoriteItem, formatBytes } from '../lib/db';
import { PreviewModal } from '../components/PreviewModal';

interface VaultPageProps {
  onOpenSettings: () => void;
  onLockApp: () => void;
}

type Category = 'all' | 'photo' | 'video' | 'document' | 'favorites';

export const VaultPage: React.FC<VaultPageProps> = ({ onOpenSettings, onLockApp }) => {
  const [items, setItems] = useState<VaultItem[]>([]);
  const [search, setSearch] = useState<string>('');
  const [activeTab, setActiveTab] = useState<Category>('all');
  const [selectedItem, setSelectedItem] = useState<VaultItem | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const loadItems = async () => {
    const list = await getAllVaultItems();
    setItems(list);
  };

  useEffect(() => {
    loadItems();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      let type: 'photo' | 'video' | 'document' = 'document';
      if (file.type.startsWith('image/')) type = 'photo';
      else if (file.type.startsWith('video/')) type = 'video';

      const reader = new FileReader();
      await new Promise<void>((resolve) => {
        reader.onload = async () => {
          const dataUrl = reader.result as string;
          const newItem: VaultItem = {
            id: 'vault_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8),
            name: file.name,
            size: file.size,
            type,
            mimeType: file.type,
            dataUrl,
            createdAt: Date.now(),
            isFavorite: false,
          };
          await saveVaultItem(newItem);
          resolve();
        };
        reader.readAsDataURL(file);
      });
    }
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    await loadItems();
  };

  const handleDelete = async (id: string) => {
    await deleteVaultItem(id);
    if (selectedItem?.id === id) setSelectedItem(null);
    await loadItems();
  };

  const handleToggleFavorite = async (id: string) => {
    await toggleFavoriteItem(id);
    if (selectedItem?.id === id) {
      setSelectedItem((prev) => (prev ? { ...prev, isFavorite: !prev.isFavorite } : null));
    }
    await loadItems();
  };

  // Filter items
  const filtered = items.filter((item) => {
    if (search.trim() && !item.name.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (activeTab === 'favorites') return item.isFavorite;
    if (activeTab === 'photo') return item.type === 'photo';
    if (activeTab === 'video') return item.type === 'video';
    if (activeTab === 'document') return item.type === 'document';
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-[#0a0f0d] text-slate-100 select-none">
      {/* Top Header */}
      <header className="px-5 pt-4 pb-3 flex items-center justify-between border-b border-[#18241e] bg-[#0c1410]/95 backdrop-blur-md sticky top-0 z-30 pt-safe">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl gradient-accent flex items-center justify-center shadow-md shadow-emerald-500/20">
            <Shield className="w-5 h-5 text-black" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white leading-tight">
              Quick<span className="text-gradient">Vault</span>
            </h1>
            <p className="text-[10px] font-semibold text-emerald-400 uppercase tracking-wider">
              {items.length} Files Encrypted
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onLockApp}
            className="p-2 rounded-xl bg-[#141f19] hover:bg-[#1a2b22] text-slate-300 border border-[#203227] transition"
            title="Lock Vault"
          >
            <Shield className="w-4 h-4 text-emerald-400" />
          </button>
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl bg-[#141f19] hover:bg-[#1a2b22] text-slate-300 border border-[#203227] transition"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Search & Category Filter Tabs */}
      <div className="px-4 py-3 space-y-3 bg-[#0a0f0d]">
        {/* Search Bar */}
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Search hidden files..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#121c17] border border-[#1d2d24] rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
          />
        </div>

        {/* Categories Horizontal Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            { id: 'all', label: 'All Files', icon: FolderOpen },
            { id: 'photo', label: 'Photos', icon: ImageIcon },
            { id: 'video', label: 'Videos', icon: Film },
            { id: 'document', label: 'Documents', icon: FileText },
            { id: 'favorites', label: 'Saved', icon: Bookmark },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as Category)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                  active
                    ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/20'
                    : 'bg-[#121c17] text-slate-400 hover:text-slate-200 border border-[#1e2e25]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Media Grid */}
      <main className="flex-1 overflow-y-auto px-4 pb-24">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center px-6">
            <div className="w-16 h-16 rounded-3xl bg-[#141f19] border border-[#203227] flex items-center justify-center text-slate-500 mb-4">
              <FolderOpen className="w-8 h-8 text-emerald-500/60" />
            </div>
            <h3 className="font-bold text-sm text-slate-200">No files here yet</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-[240px]">
              Tap the <span className="text-emerald-400 font-semibold">+</span> button below to hide photos, videos, or documents into your vault.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2.5">
            {filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className="group relative aspect-square rounded-2xl overflow-hidden bg-[#131d18] border border-[#1c2c23] shadow-sm active:scale-95 transition cursor-pointer"
              >
                {item.type === 'photo' ? (
                  <img
                    src={item.dataUrl}
                    alt={item.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                ) : item.type === 'video' ? (
                  <div className="relative w-full h-full flex items-center justify-center bg-black/60">
                    <video src={item.dataUrl} className="w-full h-full object-cover opacity-80" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="w-8 h-8 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center text-emerald-400 shadow">
                        <Play className="w-4 h-4 ml-0.5" fill="currentColor" />
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-2 text-center bg-[#131d18]">
                    <FileText className="w-7 h-7 text-emerald-400 mb-1" />
                    <p className="text-[10px] text-slate-300 font-medium line-clamp-2 break-all">
                      {item.name}
                    </p>
                  </div>
                )}

                {/* Favorite Star Badge */}
                {item.isFavorite && (
                  <span className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/70 backdrop-blur-sm text-amber-400">
                    <Bookmark className="w-3 h-3" fill="currentColor" />
                  </span>
                )}

                {/* File size overlay */}
                <span className="absolute bottom-1 right-1.5 text-[9px] font-medium text-slate-300 bg-black/60 backdrop-blur-sm px-1.5 py-0.5 rounded-md">
                  {formatBytes(item.size)}
                </span>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Floating Action Button (+) */}
      <div className="fixed bottom-6 right-6 z-40 pb-safe">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          multiple
          className="hidden"
          accept="image/*,video/*,.pdf,.doc,.docx,.txt"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="w-14 h-14 rounded-full gradient-accent flex items-center justify-center text-black shadow-xl shadow-emerald-500/30 active:scale-95 transition hover:brightness-110"
          title="Add File to Vault"
        >
          {isUploading ? (
            <span className="w-6 h-6 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
          ) : (
            <Plus className="w-7 h-7" strokeWidth={2.8} />
          )}
        </button>
      </div>

      {/* Modal Preview */}
      {selectedItem && (
        <PreviewModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          onToggleFavorite={handleToggleFavorite}
          onDelete={handleDelete}
        />
      )}
    </div>
  );
};
