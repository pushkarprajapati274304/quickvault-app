const PIN_KEY = 'quickvault_pin_hash';
const BIOMETRIC_KEY = 'quickvault_biometric_enabled';
const LOCK_TIMEOUT_KEY = 'quickvault_lock_timeout_ms';

// Simple fast SHA-256 hash using Web Crypto API
export async function hashPin(pin: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(pin + '_quickvault_salt_');
  const buffer = await crypto.subtle.digest('SHA-256', data);
  const array = Array.from(new Uint8Array(buffer));
  return array.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function isPinSet(): boolean {
  return !!localStorage.getItem(PIN_KEY);
}

export async function setAppPin(pin: string): Promise<void> {
  const hash = await hashPin(pin);
  localStorage.setItem(PIN_KEY, hash);
}

export async function verifyAppPin(pin: string): Promise<boolean> {
  const savedHash = localStorage.getItem(PIN_KEY);
  if (!savedHash) return true; // If no PIN configured, allow access
  const hash = await hashPin(pin);
  return hash === savedHash;
}

export function removeAppPin(): void {
  localStorage.removeItem(PIN_KEY);
  localStorage.removeItem(BIOMETRIC_KEY);
}

export function isBiometricEnabled(): boolean {
  return localStorage.getItem(BIOMETRIC_KEY) === 'true';
}

export function setBiometricEnabled(enabled: boolean): void {
  localStorage.setItem(BIOMETRIC_KEY, enabled ? 'true' : 'false');
}

export function canUseBiometrics(): boolean {
  return typeof window !== 'undefined' && (
    !!window.PublicKeyCredential ||
    (navigator as any).credentials !== undefined
  );
}

export async function promptBiometricAuth(): Promise<boolean> {
  if (!isBiometricEnabled() || !canUseBiometrics()) return false;
  try {
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    
    // Test biometric prompt via WebAuthn
    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge,
        timeout: 60000,
        userVerification: 'preferred',
      }
    });
    return !!assertion;
  } catch (e) {
    console.warn('Biometric cancelled or failed:', e);
    return false;
  }
}
